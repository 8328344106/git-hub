const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ProductSchema = new Schema({

    userID:Intl,
    firstName: String,
    lastName: String,
    phone:Number,
    email:String,
    address :{
        addressLine:String,
        city:String,
        state:String,
        zipCode:Number
    }
    // name: {type: String, required: true, max: 100},
    // price: {type: Number, required: true},
});


// Export the model
module.exports = mongoose.model('Users', ProductSchema);